select * from student; -- 查询学生表
delete from student; -- 删除学生表