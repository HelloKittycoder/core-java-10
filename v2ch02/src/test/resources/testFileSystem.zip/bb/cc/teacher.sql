select * from teacher; -- 查询老师表
delete from teacher; -- 删除老师表